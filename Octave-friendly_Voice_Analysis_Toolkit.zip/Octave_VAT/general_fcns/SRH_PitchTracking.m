function [f0,VUVDecisions,SRHVal,time] = SRH_PitchTracking(wave,Fs,F0min,F0max)

% USAGE:
% [f0,VUVDecisions,SRHVal] = SRH_PitchTracking(wave,Fs,F0min,F0max)
% 
% INPUTS:
%     - wave is the speech signal
%     - Fs is the sampling frequency (Hz)
%     - F0min is the minimum value for F0 search (Hz)
%     - F0max is the maximum value for F0 search (Hz)
%    
% OUPUTS:
%     - f0 is the vector of F0 values (with an hopsize of 10ms)
%     - VUVDecisions is the vector of voiced-unvoiced VUVDecisions (with an hopsize of 10ms)
%     - SRHVal is the vector of SRH values (with an hopsize of 10ms)
%     
% For more information, please read:
% 
% T.Drugman, A.Alwan, "Joint Robust Voicing Detection and Pitch Estimation
% Based on Residual Harmonics", Interspeech11, Firenze, Italy, 2011
%
% Please refer to this work in your publication if you use this code.
% 
% Code written by Thomas Drugman in TCTS Lab, University of Mons, Belgium.
% 
% Copyright (C) 2000-2011 Thomas Drugman - TCTS Lab
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
% Matlab version used for developing this code: 7.0
%
% http://tcts.fpms.ac.be/~drugman/      thomas.drugman@umons.ac.be

%display('Tracking Pitch with SRH Method')
pause(0.0001)

if Fs>16000
    wave=resample(wave,16000,Fs);
    Fs=16000;
end

LPCorder=round(3/4*Fs/1000);
Niter=2;

res = GetLPCresidual(wave,round(25/1000*Fs),round(5/1000*Fs),LPCorder);

%% Estimate the pitch track in 2 iterations
% PrevF0meanEst=0;
for Iter=1:Niter   

    [f0,SRHVal,time] = SRH_EstimatePitch(res',Fs,F0min,F0max);
    
    posiTmp=find(SRHVal>0.1);
    
    if length(posiTmp)>1
        F0meanEst=median(f0(posiTmp));
        
        % Delta=abs(F0meanEst-PrevF0meanEst);
        F0min=round(0.5*F0meanEst);
        F0max=round(2*F0meanEst);
        
        % PrevF0meanEst=F0meanEst;
    end
    
end

% Voiced-Unvoiced decisions are derived from the value of SRH (Summation of
% Residual Harmonics)
VUVDecisions=zeros(1,length(f0));
Threshold=0.07;
if std(SRHVal)>0.05
    Threshold=0.085;
end

pos= SRHVal>Threshold;
VUVDecisions(pos)=1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%


