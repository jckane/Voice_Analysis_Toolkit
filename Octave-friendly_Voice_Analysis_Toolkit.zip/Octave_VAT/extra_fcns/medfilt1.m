function y = medfilt1(x,N)

% Function to do median filtering on a one-dimensional signal x. N should be an odd number, and otherwise it is reduced by one.

if rem(N,2)==0
   disp('Medfilt1 - reducing N by 1')
   N=N-1;
end

y=x;

halfLen=(N-1)/2;
start=halfLen+1;
stop=length(x)-halfLen;

for m=start:stop
   y(m) = median(x(m-halfLen:m+halfLen));
end

   


